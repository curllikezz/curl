<?php
$dataLog  =  array(
'email' => '100012873108597',
'pass' => 'Tuan1997',
'apps' =>'41158896424',# ID Applikasi nya
);

?>