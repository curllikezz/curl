<?php
$domain= 'http://ungdung.online/a/'; // không có / ở cuối
$linktoken= 'http://ungdung.online/a/token.txt'; // nên để trong file txt nhé
$id_hoadz='100007232988005'; // ID User VIP
?>